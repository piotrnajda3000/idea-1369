# Sizing, Workload and Scaling Insights: UX Project Brief

## 1. Summary

### Links

| | |
|---|---|
| **Jira / Tracker** | [AV-94227](https://jira.issues.couchbase.com/browse/AV-94227) |
| **PRD** | [PRD - Capella: Sizing, Workload and Scaling Insights](https://docs.google.com/document/d/1iDTusohKevFL_vo51S8AxU5MVWixm4HxKnLxzIOrD8s/edit) — status APPROVED, v1.0 |
| **Slack channel** | [TBD] |
| **Related docs** | [New Sizing Calculator FAQ](https://docs.google.com/document/d/1ObzQZkIRlTKscYSrHOYJxBf0gJKh6d2ouzDFG2wjD9M/edit) · [Capella Workload Monitoring UI](https://docs.google.com/document/d/1yNvDAJoTqlABTurydMIVEI9oG1Am-zPei4b1oBjSKv4/edit) · [Product Concept: Capella Fusion 2](https://docs.google.com/document/d/1dr1OYtWvcyT_hiaUlqg1Vd_gW4vX4zPlYlPx6fGJBlY/edit) · [Capella Workload Patterns](https://docs.google.com/document/d/1dAk7YtuOzsJ7rSOVYzlT55w7PAIRDQNXhjOD1fpXEn4/edit) |
| **Design review feedback** | Min → Skylar, Aug 2026 — cited inline as *(design review, Aug 2026)* |

### Team & stakeholders

| Role | Name(s) |
|---|---|
| UX / Design | Skylar Kurth |
| Product Manager | Shivani Gupta |
| Engineering Leads | Andrea Bozzola (EM), Aditya Venkatesan (UX-UI Eng) |
| Frontend / Fullstack | [TBD] |
| Backend / Server | [TBD] |
| SRE | Santhosh Karuhatty |
| Support | Ajay Upputuri |
| Performance | Bo-Chun Wang |
| Documentation | Tim Fletcher |
| Field Engineering | David Elliott |
| **Sign-off by** | [TBD — PRD lists approvers, but no UX design sign-off owner] |

### Plan & deliverables

| | |
|---|---|
| **Detailed plan** | [TBD] |
| **Target completion (UX)** | [TBD] |
| **Targeted release** | [TBD] — P0 items are phase 1, P1 phase 2, P2 discretionary |
| **UX handoff (Figma)** | [TBD] |

## 2. Background & problem

### Background / context

Every Capella cluster begins with a sizing, and today that sizing is done *for* the customer by
the field team using an internal tool at sizing.couchbase.com behind VPN. Because it is a
one-time act the customer cannot repeat, it gets done conservatively — sized for peak workload
plus buffer — and never revisited. Customers have no view of their own workload patterns in
Capella at any timescale, so they end up either paying for idle capacity or running undersized
and calling Support. Fusion is the trigger: its whole value proposition is Express Scaling, and
scaling guidance a customer cannot see or act on makes that proposition unusable.

### Problem statement

A DevOps engineer operating a Capella cluster needs to see how their workload actually behaves
and what size it warrants, so they can right-size instead of over-provisioning — but today
sizing lives in an internal VPN-only tool they cannot reach and Capella shows them no workload
history at all.

### Objective

Self-service sizing and workload visibility in Capella, so customers can right-size their own
clusters instead of asking the field team.

### Success metrics & key results

| Metric | Type | Baseline | Target |
|---|---|---|---|
| P95 latency for the sizing calculator to return a sizing | Leading | n/a — new | Under 30 seconds (PRD, Performance requirements) |
| Sizing calculator invocations per tenant | Leading | 0 | [TBD] |
| [TBD — TCO reduction from right-sizing] | Lagging | [TBD] | [TBD] |
| [TBD — reduction in undersized-cluster Support cases] | Lagging | [TBD] | [TBD] |

The PRD argues value in terms of TCO savings, SLA adherence and avoided Support calls, but sets
no target for any of them. The only stated number is the latency requirement.

## 3. User stories & user tasks

| # | User story & user task | Priority | Status |
|---|---|---|---|
| 1 | **In-Capella sizing calculator** As a DevOps engineer without a field engineer, I need to size a cluster myself so that I can provision the right capacity without filing a request. | P0 | Not Started |
| 2 | **Workload insights dashboard** As a DevOps engineer, I need to see how my incoming workload changes over time so that I can tell whether my cluster is the right size. | P0 | Not Started |
| 3 | **Scaling insights** As a DevOps engineer, I need a selected span of my workload chart translated into a sizing recommendation so that I know what to change and by how much. | P0 | Not Started |
| 4 | **Undersize protection** As a DevOps engineer, I need to be warned when my cluster is undersized — and before a scale-in makes it so — so that I don't degrade my own service. | P0 | Not Started |
| 5 | **Sizing for a new application** As a DevOps engineer adding an app to an existing cluster, I need to know how much net-new capacity each service needs so that I can expand safely. | P1 | Not Started |
| 6 | **Workload pattern detection** As a DevOps engineer, I need Capella to recognise my recurring patterns (circadian, weekend slowdown, seasonal peak) so that I can schedule scaling against them. | P2 | Not Started |

Status reflects that no UX work is recorded against this brief. The PRD states UX "is being
designed by Skylar Kurth" in the present tense, and a design review took place in Aug 2026 —
confirm actual state before using this table.

| # | Sub-task — In-Capella sizing calculator | Priority | Status |
|---|---|---|---|
| 1.1 | Basic and Advanced modes, covering all Capella Operational services (data, query, index, search, eventing) from launch. | P0 | Not Started |
| 1.2 | Caution that output is an estimate: *"This tool provides an estimated sizing. For precise results, you must test and validate the sizing using your actual workload."* | P0 | Not Started |
| 1.3 | Reachable from Settings → Cluster Sizing, the Projects page, and the Create Cluster page. | P0 | Not Started |
| 1.4 | Save a sizing (inputs and outputs); view the last 10 saved sizings. | P0 | Not Started |
| 1.5 | Carry a selected sizing into the Create Cluster flow, pre-populating instances — without creating the cluster. | P0 | Not Started |
| 1.6 | Reachable from the workload insights dashboard with workload metrics pre-filled. | P0 | Not Started |
| 1.7 | Behind a feature flag, rolled out gradually. | P0 | Not Started |
| 1.8 | Variable-workload sizing: multiple workload levels against one data size and one hardware profile, with named pattern templates (DR, weekend slowdown, daily circadian, seasonal peak, unpredictable peak). | P0 | Not Started |
| 1.9 | Workload-pattern sizing for indexes (GSI, Search, Vector). | P1 | Not Started |
| 1.10 | TCO comparison: variable sizing vs a single peak size, with and without Fusion. | P2 | Not Started |

| # | Sub-task — Workload insights dashboard | Priority | Status |
|---|---|---|---|
| 2.1 | Data service first — reads/sec, writes/sec (including updates and deletes), plus data size. | P0 | Not Started |
| 2.2 | Works whether or not Fusion is enabled on the cluster. | P0 | Not Started |
| 2.3 | History views: week, 30 days, 90 days (90-day may be coarser granularity). | P0 | Not Started |
| 2.4 | History view: 1 year, coarser granularity (e.g. 5-minute averages). | P1 | Not Started |
| 2.5 | Extend to Query, Indexes (GSI, Search, Vector) and Eventing. | P1 | Not Started |
| 2.6 | Extend to Analytics. | P2 | Not Started |

### States

| States | Where it applies | Priority | Status |
|---|---|---|---|
| Metric repository down | Workload insights, scaling insights | P0 | Not Started |
| Cluster off / paused — no metrics collected for the period | Workload insights charts | P0 | Not Started |
| No history yet (new cluster, or shorter than the selected range) | Workload insights, 30/90-day and 1-year views | P0 | Not Started |
| Feature flag off | Sizing calculator entry points, workload dashboard | P0 | Not Started |
| Sizing in progress (P95 up to 30s) | Sizing calculator | P0 | Not Started |
| Estimate caution / disclaimer | Sizing calculator output | P0 | Not Started |
| Undersized-cluster warning | Cluster health, scale-in flow | P0 | Not Started |
| Guardrail hit — invocation limit reached | Sizing calculator | P0 | Not Started |
| No permission (RBAC) to size or to view insights — hidden, disabled, or empty? | All three surfaces | P0 | Not Started |
| Incomplete form — required fields not yet filled | Sizing calculator | P0 | Not Started |
| Error handling — the PRD's Error Conditions section reads "—-This section is TBD—-" | All three surfaces | P0 | Not Started |

### Edge cases

| Edge cases | Where it applies | Priority | Status |
|---|---|---|---|
| Scale-in that would leave the cluster undersized — warning must be overridable, never blocking | Scale-in via UI and Management API | P0 | Not Started |
| Sizing done before any cluster exists | Projects page, Create Cluster | P0 | Not Started |
| Cluster changed between recommendation and action (recommend +5, one node removed, now +6) | Scaling insights | P0 | Not Started |
| Saved sizing #11 when only 10 are retained | Sizing list | P0 | Not Started |
| Saved sizing whose Server version or instance types are no longer offered | Sizing list, Create Cluster hand-off | P0 | Not Started |
| Scaling down costs more than it saves once Fusion's static and variable components are counted | TCO comparison | P2 | Not Started |
| Tier gating — Enterprise P0, DevPro and Free P1 | All three surfaces | P1 | Not Started |
| Fusion unavailable or off — every feature must still stand alone | All three surfaces | P0 | Not Started |
| Field user sizing on behalf of a customer via the Field Tenant | Sizing calculator | [TBD] | Not Started |
| SRE kill switch engaged (sizing links, scaling insights, or metrics collection disabled) | All three surfaces | [TBD] | Not Started |

## 4. Objects, fields & provenance

### Object identity — is a "sizing" a thing, or a result?

The PRD says sizings are saved and listed ("save the sizing… view all previously saved sizing…
limit it to saving history of past 10"), which makes it an object. Nothing else about it is
defined, and a list of objects a user cannot open, version, or act on reads as broken.

| | |
|---|---|
| **Persists as an object?** | Yes — inputs and outputs both saved (PRD) |
| **Detail view** | [TBD] — can a row be opened? what's on it? *(design review, Aug 2026)* |
| **Versioning** | [TBD] — new version of an existing sizing, or only ever a new one? *(design review, Aug 2026)* |
| **Duplicate / rename / export** | [TBD] — a copy control exists in the design; its unit is unclear *(design review, Aug 2026)* |
| **Retention** | Last 10 per [TBD — tenant? project? user?] |
| **Visibility** | [TBD] — org-wide, project-scoped, or private to the creator? |
| **Not an object but looks like one** | If a saved sizing is really a static snapshot rather than a live config, say so on the surface — users will otherwise expect to edit and re-run it |

### Field provenance

The PRD does not enumerate the form. The field groups below are drawn from the current design
*(design review, Aug 2026)*. **Provenance is unassigned for every one of them** — this is the
single largest definition gap in the project, because the same screen mixes values the user
supplies with values the tool returns.

| Field group | Fields | Provenance | Required? | Where the user gets the value |
|---|---|---|---|---|
| Identification | Sizing name, Sizing ID | Name = user input; ID = system-generated | [TBD] | ID needs no user attention — a name serves identification |
| Cluster target | Cloud provider, region, AZ, Server version, cluster name | [TBD] — chosen, or inherited from an existing cluster? | [TBD] | |
| Environment / document settings | data size, document count, working-set % | [TBD] | [TBD] | user knows, or estimates |
| Workload | reads/sec, writes/sec, workload pattern | [TBD] | [TBD] | user estimates; pattern templates help |
| Service groups | instance type, CPU, RAM, disk type, size, IOPS, network bandwidth, node count | **[TBD] — the critical one.** Are these the user's *current* cluster, or their *intended* target? The tool is meant to return CPU/RAM/IOPS, so asking for them as input is ambiguous | [TBD] | |
| Node count | number of nodes per service group | Locked in the current design | n/a | Locked = computed. If so, say so; if not, unlock |
| Data service configuration | per-bucket / per-collection sizing | [TBD] | [TBD] | |
| Feature toggles | XDCR, backup, backup daily change rate | [TBD] | [TBD] | |
| Summary card | AZ, Server version, nodes, service groups | Computed — read-only | n/a | Must mirror the main section's order and vocabulary |

**Duplication to resolve.** CPU and RAM appear both in hardware input and in the services
section; data service is configured both under a service group and per bucket. For each: same
value, a sum, an override, or unrelated — and which wins? *(design review, Aug 2026)*

**Value sourcing.** Many fields are Couchbase-specific (working set, IOPS, daily change rate).
For each, state whether the DevOps persona knows it, looks it up, or guesses — and what a wrong
guess costs. Fields the user cannot answer are worse than fields that aren't there.

## 5. IA & key flows

### Placement & entry points

The PRD places the calculator under Settings → Cluster Sizing and the Projects page. The design
review argues it belongs with the work it serves — cluster creation and cluster resize — rather
than standing alone under the org tab *(design review, Aug 2026)*. Unresolved.

| | |
|---|---|
| **Jobs it serves** | Create a cluster · Resize a cluster (services / node editing) · Add an app to an existing cluster |
| **Where it lives** | [TBD] — org-level surface vs. embedded in cluster create/resize |
| **Links in from** | Create Cluster (PRD, P0) · Workload insights, with metrics pre-filled (PRD, P0) · Cluster resize *(proposed, design review)* |
| **Links back out to** | Create Cluster, pre-populating instances without creating the cluster (PRD, P0) |

### Terminal state — what does "Calculate sizing" produce?

The PRD leaves this undefined on a **P0** requirement: *"the sizing calculator should be
invokable via APIs from Capella. All the inputs are automatically decipherable. **The output
UI/UX is TBD.**"* The design review independently lands in the same place — no visible result,
no clear next action *(design review, Aug 2026)*. This is the largest undefined surface in the
project.

| | |
|---|---|
| **Primary action** | Calculate sizing |
| **What it produces** | [TBD] — node counts per service? a full instance recommendation? a diff against the current cluster? |
| **Where the output appears** | [TBD] — in place, on a detail page, or appended to the sizings list |
| **What the user does next** | [TBD] — save, create a cluster, resize, export, share |
| **Scaling-insights variant** | [TBD] — same output shape as a from-scratch sizing, or a delta ("remove 9 nodes at 9pm")? |

### Field dependency & order

| Field | Constrains | Must come before |
|---|---|---|
| Cloud provider | available regions, instance types | region, instance selection |
| Service groups | which services can be configured per bucket | data service / bucket configuration |
| Server version | available features and instance types | [TBD] |

Reading order must match dependency order. Where a later field constrains an earlier one, the
order is wrong *(design review, Aug 2026)*.

### Action legibility

| Control | Question |
|---|---|
| Copy (next to Delete, Data service configuration) | Copies what — the row, the group, the whole config? |
| XDCR / backup toggles | Position implies a mode or view switch; if they are service config, they belong at the same level as the other service settings |

## 6. Platform impact & prerequisites

| Dimension | Impact? | What the source says | Open question |
|---|---|---|---|
| **Billing & monetization** | Indirect | "does not change the unit price of Capella"; "free of any additional cost". But TCO output calls "the Capella cost APIs with relevant special parameters to indicate Fusion being enabled", and Fusion itself is chargeable | Does showing Fusion-adjusted pricing in the calculator create a quoted-price expectation? Who owns accuracy if the estimate and the invoice disagree? |
| **Security & data** | Yes | New long-lived workload metrics per cluster, retained up to 1 year | Retention, tenancy isolation, and whether workload history survives cluster deletion — all [TBD] |
| **RBAC compatibility** | Yes — P0 | Three RBAC requirements, all expressed as capabilities, none as named roles | See sub-table |
| **Performance & scale** | Yes — P0 | P95 < 30s; 50 concurrent calls across tenants; guardrails on invocation rate; 1-year metric retention | Guardrail numbers are written as open questions in the PRD |
| **Prerequisites** | Yes | Metrics pipeline retaining ~1 year; alerting/notification framework (explicitly out of scope, blocks the P2 custom alerts) | Does the metrics pipeline retain a year today, or is that new work? |
| **Dependencies** | Yes | Fusion; the Capella Workload Monitoring UI project; Capella cost APIs; Server version sync | Who owns the workload dashboard design? |

### RBAC compatibility

The PRD grants access by capability. Capella grants by named role. The mapping is undone.

| Capability the PRD describes | Named role(s) it maps to | Exists today? | Notes |
|---|---|---|---|
| "Any user that can deploy a cluster or change the cluster configuration" → use the Sizing Calculator | `projectOwner`, `projectClusterManager`, `projectCreator`, `organizationOwner` | Roles exist; the mapping is not stated | Sources: `internal/rbac`, `internal/auth` |
| "Same as the new Workload Dashboards" → view workload insights | [TBD] — depends on a decision in the Workload Monitoring UI project | [TBD] | Inherits an unresolved dependency |
| "Same as who can access the Sizing Calculator" → view scaling insights | as row 1 | [TBD] | |
| Field team sizing for customers via the Field Tenant | [TBD] — no customer role covers cross-tenant access | [TBD] | Internal access path, undesigned |

Unanswered: does a viewer-level role (`projectClusterViewer`, `projectDataViewer`) see the
workload dashboard but not the calculator? And what does a user without permission see —
feature hidden, control disabled, or an empty state with an explanation?

### Prerequisites & dependencies

| Item | Type | Owner | Blocks | Status |
|---|---|---|---|---|
| Metrics pipeline retaining workload metrics ~1 year | Prerequisite | [TBD] | Stories 2, 3, 6 | [TBD] |
| Capella Workload Monitoring UI project | Dependency | [TBD] | Story 2 entirely | In flight — PRD says these requirements "should be incorporated into that project" |
| Fusion / Express Scaling | Dependency | Fusion team | Stories 3, 6 value; none blocked outright | [TBD] |
| Capella alerting & notification framework | Prerequisite | Out of scope per PRD | P2 custom workload alerts only | Not started |
| Capella cost APIs with Fusion parameters | Dependency | [TBD] | Sub-task 1.10 (TCO) | [TBD] |
| Feature flags — calculator, workload dashboard | Prerequisite | [TBD] | Rollout of stories 1, 2 | [TBD] |
| SRE kill switches — sizing links, scaling insights, metrics collection | Prerequisite | Santhosh Karuhatty | Launch readiness | [TBD] |
| Sizing calculator ↔ Server version sync | Dependency | [TBD] | Ongoing accuracy of story 1 | [TBD] |

## 7. Open questions

| Question | Owner | Raised | Answer / status |
|---|---|---|---|
| **What does "Calculate sizing" actually produce, and where does it land?** The PRD marks the output UI/UX "TBD" on a P0; the design review reached the same dead end independently. | Shivani Gupta / Skylar Kurth | 2026-08-23 | Open — largest undefined surface in the project |
| **Field provenance across the whole form.** Which values does the user supply, which are suggested defaults, which does the tool compute? Currently indistinguishable on screen. | Shivani Gupta / Skylar Kurth | 2026-08-23 | Open |
| Service-group hardware — is the user describing their **current** cluster or their **intended** one? The tool is meant to output CPU/RAM/IOPS, so asking for them as input is ambiguous. | Shivani Gupta | 2026-08-23 | Open |
| Node count is locked in the current design. Is it computed, or an unimplemented input? If computed, the UI must say so. | Skylar Kurth | 2026-08-23 | Open |
| CPU/RAM appear in both hardware input and services; data service is configured both per service group and per bucket. Same value, sum, or override — and which wins? | Shivani Gupta | 2026-08-23 | Open |
| Is a saved sizing an openable, versionable object, or a static snapshot? Can it be duplicated, renamed, exported? Who else can see it? | Shivani Gupta | 2026-08-23 | Open |
| Placement — org-level surface, or embedded in cluster create/resize where the job actually happens? | Aditya Venkatesan / Skylar Kurth | 2026-08-23 | Open |
| **RBAC:** the PRD grants by capability, Capella grants by named role. Which roles map, and does a viewer role see the dashboard but not the calculator? | Shivani Gupta / [TBD] | 2026-08-23 | Open |
| **RBAC:** field users sizing via the Field Tenant have no equivalent in the customer role model. How is that access expressed? | Shivani Gupta | 2026-08-23 | Open |
| What does a user *without* permission see — feature hidden, disabled, or explained? | Skylar Kurth | 2026-08-23 | Open |
| **Prerequisite:** does the metrics pipeline retain a year of workload metrics today, or is that new work on the critical path? | Santhosh Karuhatty | 2026-08-23 | Open |
| **Dependency:** Workload Insights is to be "incorporated into" the Workload Monitoring UI project. Who owns the dashboard design — one surface or two? | Aditya Venkatesan | 2026-08-23 | Open |
| **Billing:** TCO output calls the Capella cost APIs with Fusion parameters. Does a Fusion-adjusted figure read as a quote? Who owns it if estimate and invoice diverge? | Shivani Gupta | 2026-08-23 | Open |
| **Performance:** guardrails are written as questions — "no more 5 invocations in 10 mins?", "No more than 100 invocations per day?". What are the real limits, and what does hitting one look like? | Shivani Gupta / SRE | 2026-08-23 | Open |
| **Security:** what is the retention policy for workload metrics, and does history survive cluster deletion? | Santhosh Karuhatty | 2026-08-23 | Open |
| Error Conditions is an empty section ("—-This section is TBD—-") yet Reliability requires "appropriate error messages" at P0. Which failures need designed states? | Shivani Gupta | 2026-08-23 | Open |
| Cluster-off periods: the PRD hedges — label the gap, or show zero workload? These read very differently on a chart. | Shivani Gupta | 2026-08-23 | Open — hedge, not a decision |
| A late NOTE says one combined tool serves both field and customer, but the requirements remain split in two. Does the Field Tenant path change the UI, or only access? | Shivani Gupta | 2026-08-23 | Open |
| Which Couchbase-specific fields does the DevOps persona actually know, versus look up or guess — and what does a wrong guess cost? | Shivani Gupta | 2026-08-23 | Open |
| No success metric has a baseline or target. Six months after launch, what number tells us right-sizing worked? | Shivani Gupta | 2026-08-23 | Open |
| Free tier: "could provide the sizing calculator, and the workload insights and the scaling insights - P1" — all three, or aspirational? | Shivani Gupta | 2026-08-23 | Open |
| Over-sized alerts carry "I suggest we do not do this initially" (P2). In or out for phase 1 design? | Shivani Gupta / Ajay Upputuri | 2026-08-23 | Open |
| Who signs off UX before engineering handoff? The PRD lists PRD approvers, not a design approver. | [TBD] | 2026-08-23 | Open |

## 8. Assumptions

Recorded as assumptions, not requirements — believed, not validated.

| Assumption | Source | Validated? |
|---|---|---|
| Placement belongs with cluster creation and resize rather than a standalone org-level surface | Design review, Aug 2026 | No — design judgement, no user research behind it |
| A user-supplied sizing name serves identification better than a prominent generated ID | Design review, Aug 2026 | No |
| Overall flow should settle before component styling is dialled in | Design review, Aug 2026 | No — process preference |
