# Definition questions

Run these against any surface where the user fills in fields, configures something, or produces
a result. Every one that the source material cannot answer becomes a row in Open questions.

These are **definition** questions, not critique questions. They are cheap to ask before design
starts and expensive to discover in review — the answers change the flow, not the pixels.
Layout, grouping, spacing, component styling and scannability are review-time concerns; leave
them to `/review-design`.

---

## 1. Object identity — is this a thing, or a result?

The most common unasked question. A "calculation", "report", "estimate" or "draft" either
persists as an object with a lifecycle, or it is a transient output. Which one drives
navigation, permissions, and half the empty states.

- Is what the user produces an object that persists, or a one-off result?
- Can the user open one and see its detail? What is *on* that detail view?
- Can they create a new **version** of an existing one, or only ever start over?
- Can they duplicate, rename, export, share, delete? Who else can see it?
- Is there a retention limit (e.g. "last 10")? What happens to number 11?
- If it is not an object — is it a file? a link? a snapshot? Say so explicitly, because the
  user will try to treat it as an object.

## 2. Field provenance — who supplies each value?

Every field on a form has exactly one provenance. If the brief does not say which, the design
will mix them and the user will not be able to tell what they are looking at.

| Provenance | Meaning | Must be visibly distinct |
|---|---|---|
| User input | The user must supply it | Editable, and required-ness is legible |
| Suggested default | Pre-filled, user may change | Clearly a suggestion, not a fact |
| Computed | Derived from other fields | Never looks editable |
| System-generated | Assigned by the platform (IDs, timestamps) | Rarely deserves prominence |
| Locked | Present but not editable, by design | The *reason* for the lock is stated |

Ask:

- For each field: which of the five is it?
- Can the user tell, without being told, which values they are expected to change?
- Any locked field — why is it locked, and does the UI explain the lock?
- Any system-generated ID — does the user need to see it at all? A user-supplied name usually
  serves the same identification purpose better.

## 3. Value sourcing — does the user actually have this number?

A field the user cannot answer is worse than a field that isn't there.

- Where does the user get this value? Do they know it, look it up, or guess?
- Is the field domain jargon that needs a definition, an example, or a "how do I find this?"
- Is this value about their **current** state or their **intended** state? (A hardware field on
  a sizing tool means one thing if it describes today's cluster and the opposite if it
  describes the target.) Say which, in the label.
- What is the cost of guessing wrong — a bad estimate, or a bad cluster?

## 4. Completeness — can the user tell when they are done?

- Which fields are required and which are optional?
- Can the user see what's still missing before they submit, or only after?
- Long forms: what stops someone filling one column and missing the next?

## 5. Dependency and order — what constrains what?

- Which fields narrow the options of other fields? (Cloud provider → available regions.)
- Does the reading order match the dependency order? If a later field constrains an earlier
  one, the order is wrong.
- Is there a required sequence between sections — must A be defined before B is meaningful?

## 6. Duplication — is one concept configurable in two places?

- Does any setting appear on more than one surface or at more than one level?
- If so: are they the same value, a sum, an override, or unrelated?
- Which one wins, and does the UI say?
- Do totals across a group have to reconcile with a value set above it? Say whether that's a
  constraint, a validation, or a coincidence.

## 7. Terminal state — what does the primary action produce?

Frequently the biggest hole in a spec, and always a P0.

- What exactly happens when the user hits the primary action?
- Where does the output appear — in place, on a new page, appended to a list?
- What does the output *look like*? A number, a table, a recommendation, a diff against today?
- What is the user meant to do next with it? Save, act, export, share, discard?
- If a spec says the output UI is "TBD", that is not a detail — flag it as the largest
  undefined surface in the project.

## 8. Placement — where does this live, and what links to it?

- Which existing jobs does this serve? It belongs near those, not in its own silo.
- Which adjacent pages should link into it, and with what context carried across?
- When the user arrives from an adjacent flow, what is pre-filled?
- On finishing, can they carry the result back into the flow they came from?

## 9. Action legibility — what does each control act on?

- For every button, icon and toggle: what exactly does it affect, and at what scope?
- Any control whose position implies a different meaning than its function (a toggle that reads
  as a view switcher, an icon that reads as a mode) is a definition problem, not a styling one.
- Destructive or duplicating actions: what is the unit — the row, the group, the whole config?

---

## Recording the answers

| Question class | Lands in |
|---|---|
| 1 Object identity, 2 Field provenance, 6 Duplication | Objects, fields & provenance |
| 5 Dependency and order, 7 Terminal state, 8 Placement | IA & key flows |
| 3 Value sourcing | Target users & context of use |
| 4 Completeness, 9 Action legibility | States & edge cases |
| Anything unanswered | Open questions |

## Opinion is not evidence

Design judgement offered without a user behind it is an **assumption**, not a requirement.
Record it as one — "we believe X; not validated" — so it can be tested rather than inherited.
A brief that blurs the two hands engineering opinions with the authority of findings.
