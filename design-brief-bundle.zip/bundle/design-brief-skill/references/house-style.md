# House style

Distilled from the real briefs: Project Lighthouse, PITR, VPC endpoint / self-managed private
service endpoint, Vector index, Create cluster, Chatbot on Capella UI.

## Controlled vocabulary

**Priority** — `P0` `P1` `P2` `P3` `P4` `P5`. P0 means "this release does not ship without it."
Do not invent a priority the source doesn't support; use `[TBD]`.

**Status** — `Not Started` · `In Progress` · `Done`. Nothing else.

**Gap marker** — `[TBD]`. Optionally `[TBD — <name> to confirm]` when the owner is known.
Every `[TBD]` in the body gets a matching row in Open questions.

## Table shapes

Tables carry the brief. Prose sections are 3–5 sentences; everything with more than two
comparable items becomes a table.

The user-story table always has this shape, in this order:

| # | User story & user task | Priority | Status |
|---|---|---|---|

Sub-tasks go in a *second* table below the parent, numbered against it (`3.1`, `3.2`, `3.3`).
Bold the story's theme at the start of the cell — **Cluster configuration**, **Contracted
entitlement** — so the table scans as an outline.

States and edge cases are two separate tables, never merged. Same four columns.

## Comparison tables earn their place

Where a feature has near-neighbours that get confused with each other, a comparison table is
worth more than paragraphs. From the private-endpoint brief:

| | Cluster | Data API | Self-managed |
|---|---|---|---|
| Direction | Inbound / ingress | Inbound / ingress | **Outbound / egress** |
| Who AWS invoices | Customer | Customer | **Capella** |

Bold the cells that differ from the established pattern — that's where the wrong assumptions
get carried over from the neighbouring feature.

Same for status/state mappings: platform state → product state → how it renders → what it means
for the user. Name the states the platform has that the product does **not** model; those
unmapped states are design work hiding in plain sight.

## Voice

- Objective is one sentence, outcome-shaped, no feature list.
  Good: *"Self-service recovery without a ticket or using a CLI."*
  Good: *"Self-service usage visibility that tracks cluster deployment and resource consumption
  against entitlements."*
  Bad: *"Build a PITR configuration screen with retention settings and a restore wizard."*
- Background names the trigger, not just the situation. *"…creating friction, delays, and
  misalignment between actual usage and contracted entitlements"* — the cost is the point.
- Cite the source when a claim comes from code or a spec: *"Sources: constants/private-endpoint-state.ts,
  mapPrivateEndpointStateToStatus."* A brief that cites is a brief that can be checked.

## Anti-patterns — push back before drafting

| Pattern | Why it fails | Do instead |
|---|---|---|
| Audience as a demographic bucket ("Capella users", "developers and admins") | Designs for nobody | Name the one person most likely to hit this first, and what blocks them |
| Objective with no number ("improve the experience") | Unfalsifiable, so unarguable | "Six months on, what number tells you it worked?" |
| Scope with no non-goals | Guarantees creep and late rework | Out-of-scope list is mandatory once Scope exists at all |
| Transcribing the PRD | Duplicates a doc that already exists | Translate: PRD says what gets built, brief says who needs it and why |
| Padding the story table to look thorough | Buries the real P0s | Five real stories beat twelve generic ones |
| Silently resolving a spec's hedge | Hides a decision nobody made | Name the hedge as an open question |
| Inventing owners, dates, or metrics | Corrodes trust in every other line | `[TBD]` + a row in Open questions |
| A form field with no stated provenance | User can't tell what's theirs to change vs computed | Declare every field: input / default / computed / system / locked |
| A primary action with no stated output | The flow has no ending; design fills the hole by guessing | Name what it produces, where it lands, and the next step |
| A new surface placed in its own silo | Orphaned from the jobs it serves | Name the adjacent flows and the links in and out |
| Design opinion recorded as requirement | Hands engineering a guess with the authority of a finding | Record it as an assumption: "we believe X; not validated" |

## Stay out of review territory

Layout, grouping, spacing, component styling, scannability and visual hierarchy are
review-time concerns — they belong to `/review-design`, not to a brief. The brief's job is
definition: what the thing is, what the fields mean, what the action produces, where it
lives. Fidelity follows: settle the overall flow before anyone dials in component styling.

## Docs handoff

Markdown tables pasted into Google Docs arrive as plain text. Run `scripts/brief_to_html.py`,
open the HTML in a browser, select all, copy, paste — Docs preserves table structure, bold, and
links from an HTML clipboard payload.
