# UX Project Brief — full format

Sections marked **LEAN CORE** are always filled. Sections marked **SUGGESTED** are offered in
Step 5 only when they earn their place. Not every project needs every section — this is a menu,
not a mandate.

---

# [Project Name]: UX Project Brief

## 1. Summary — LEAN CORE

The at-a-glance header. Anyone opening this doc finds every key link, owner, and date on the
first screen. Stale links here erode trust in the whole brief.

### Links

| | |
|---|---|
| **Jira / Tracker** | [IDEA-XXXX] |
| **PRD** | [link] |
| **Slack channel** | [#proj-channel] |
| **Related docs & channels** | [architecture doc, API spec, pricing, research repo] |

### Team & stakeholders

| Role | Name(s) |
|---|---|
| UX / Design | |
| UX Research — SUGGESTED | |
| Product Manager | |
| Engineering Leads | |
| Frontend / Fullstack | |
| Backend / Server | |
| Content / UX Writing — SUGGESTED | |
| **Sign-off by** | |

Naming a single sign-off owner prevents the "who actually approves this?" ambiguity that stalls
handoff.

### Plan & deliverables

| | |
|---|---|
| **Detailed plan** | [doc \| spreadsheet] |
| **Target completion (UX)** | |
| **Targeted release & date range** | |
| **UX handoff (Figma)** | |
| **Other deliverables** — SUGGESTED | prototype, spec, redlines, usability report |

## 2. Background & problem — LEAN CORE

### Background / context
Current situation and why we are looking at it now. Include the trigger — customer feedback,
business goal, tech change. 3–5 sentences.

### Problem statement
One or two sharp sentences framed around the user:
`[User] needs a way to [goal] because [pain], but today [obstacle].`
The single most important line in the brief — everything downstream traces back to it.

### Objective
The outcome we want to create, not the feature list. One or two sentences.

### Success metrics & key results

| Metric | Type (leading/lagging) | Baseline | Target |
|---|---|---|---|
| | | | |

Split leading (usage, task success, time-on-task) from lagging (retention, revenue, renewals).

## 3. Target users & context of use — SUGGESTED

| User type | Primary / Secondary | Goals & jobs-to-be-done | Context & pain points |
|---|---|---|---|
| | | | |

**Value sourcing.** Where the product asks the user for domain-specific values, note whether
this user actually possesses them — knows it, looks it up, or guesses — and what a wrong guess
costs. A field the user cannot answer is worse than a field that isn't there.

## 4. Scope — SUGGESTED

| In scope | Out of scope / Non-goals |
|---|---|
| | Deliberately excluded — and why, or when it may come later |

"Out of scope" is often more valuable than "in scope."

### Phasing

| Phase | Focus | Target |
|---|---|---|
| Phase 1 (MVP) | | |
| Phase 2+ | | |

## 5. User stories & user tasks — LEAN CORE

| # | User story & user task | Priority | Status | Acceptance criteria — SUGGESTED |
|---|---|---|---|---|
| 1 | As a [role], I need [task] so that [benefit]. | P0 | Not Started | Done when… |

Break large stories into sub-tasks numbered `3.1`, `3.2` in a second table under the parent.

### States & edge cases — LEAN CORE

Two separate tables. These are the states that are easy to forget and that define quality.

| States | Where it applies | Priority | Status |
|---|---|---|---|
| Empty / first-run | | P0 | Not Started |
| Loading | | | |
| Error | | | |

| Edge cases | Where it applies | Priority | Status |
|---|---|---|---|
| | | P0 | Not Started |

## 6. Objects, fields & provenance — SUGGESTED
*(LEAN CORE for any form, config, wizard or calculator — see the Step 2 promotion rule.)*

For data-heavy and configuration products. Catalog each object, the metadata it exposes, the
actions available, and — for anything the user fills in — where each value comes from.

### [Object name, e.g. Cluster]

| Level | Metadata | Action(s) |
|---|---|---|
| Cluster-level | fields exposed | View / Create / Edit / Delete |
| Node-level | | |

### Object identity

Answer these before designing the list or the detail view. If the thing the user produces is
*not* a persistent object, say so explicitly — users will otherwise try to treat it as one.

| | |
|---|---|
| **Persists as an object?** | yes / no — if no, what is it: a file, a snapshot, a link? |
| **Detail view** | can the user open one? what's on it? |
| **Versioning** | new version of an existing one, or only ever start over? |
| **Duplicate / rename / export / share** | which of these exist? |
| **Retention** | any cap (e.g. last 10)? what happens to the next one? |
| **Visibility** | who else in the org can see it? |

### Field provenance

Every field has exactly one provenance. Where the brief doesn't say, the design will mix them
and the user won't know which numbers are theirs to change.

| Field | Provenance | Required? | Where the user gets the value | Also appears in |
|---|---|---|---|---|
| [field] | user input / suggested default / computed / system-generated / locked | Required / Optional | they know it / look it up / guess | [other surface, or —] |

Locked fields state the reason for the lock. Computed fields never look editable. Fields that
appear in more than one place say which one wins.

## 7. Information architecture & key flows — SUGGESTED
*(LEAN CORE for any form, config, wizard or calculator — see the Step 2 promotion rule.)*

Page/section hierarchy and the critical end-to-end flows. Embed or link the sitemap / flow
diagram. Aligns the team on structure before pixel-level design.

### Placement & entry points

A new surface belongs near the jobs it serves, not in its own silo.

| | |
|---|---|
| **Which existing jobs does this serve?** | |
| **Where it lives in the nav** | and why there rather than a top-level home of its own |
| **Links in from** | which adjacent pages, carrying what context pre-filled |
| **Links back out to** | can the result be carried into the flow the user came from? |

### Terminal state

What the primary action produces. Usually the biggest hole in a spec, and always a P0.

| | |
|---|---|
| **Primary action** | e.g. Calculate, Save, Apply |
| **What it produces** | a number, a table, a recommendation, a diff against today |
| **Where the output appears** | in place / new page / appended to a list |
| **What the user does next** | save, act, export, share, discard |

### Field dependency & order

| Field | Constrains | Must come before |
|---|---|---|
| [e.g. Cloud provider] | available regions | region selection |

If a later field constrains an earlier one, the order is wrong.

## 8. Platform impact & prerequisites — LEAN CORE

All six dimensions are **checked on every project**. Most projects will not be touched by most
of them — that is expected. The check is mandatory; the write-up is proportional.

**Checked, no impact:** [list the dimensions that came back clean, each with the one clause that
proves you looked — e.g. *"Billing — no new metered resource, no change to tier gating."*]

A bare "no" is indistinguishable from not having checked. Give the reason, in a clause, so a
reviewer can challenge it. Then table only the dimensions that are live or uncertain:

| Dimension | Impact | What the source says | Open question |
|---|---|---|---|
| | | | |

The six to check, and what to look for in each:

| Dimension | Look for |
|---|---|
| **Billing & monetization** | unit price, tier gating, metered usage, cost APIs consumed, anything shown to the user that resembles a price |
| **Security & data** | new data collected, retention, tenancy isolation, cross-tenant or internal access paths, what survives deletion |
| **RBAC compatibility** | see the sub-table below — always worth a real check, rarely genuinely "no impact" |
| **Performance & scale** | latency targets, concurrency, storage growth, rate limits and what hitting one looks like |
| **Prerequisites** | what must ship before this can — another team's feature, API, or framework |
| **Dependencies** | what ships alongside, or is owned jointly with, another project |

### RBAC compatibility

Specs usually describe permission by *capability* ("anyone who can deploy a cluster"). The
platform grants by *named role*. Mapping one to the other is design work, and it is where the
"can I actually see this?" bugs come from.

| Capability the spec describes | Named role(s) it maps to | Exists today? | Notes |
|---|---|---|---|
| [e.g. "can deploy a cluster"] | [e.g. projectClusterManager] | yes / no / partial | |

Then answer:

- Does this need a permission the current model does not express? If so, that's a platform
  change, not a screen.
- What does a user *without* the permission see — the feature hidden, disabled, or an empty
  state? (This becomes a row in States.)
- Is there an internal or cross-tenant access path (support, field, admin)? Those rarely fit the
  customer role model and are routinely left undesigned.

### Prerequisites & dependencies

| Item | Type | Owner | Blocks | Status |
|---|---|---|---|---|
| | prerequisite / dependency | | which stories | |

A prerequisite must ship before this can. A dependency ships alongside and can move
independently. Keep pure assumptions and constraints in the next section.

## 9. Assumptions, constraints & dependencies — SUGGESTED

| Assumptions | Constraints | Dependencies |
|---|---|---|
| believed true, not confirmed | technical / platform / legal / time | teams, APIs, decisions we await |

## 10. Risks & mitigations — SUGGESTED

| Risk | Likelihood | Impact | Mitigation / owner |
|---|---|---|---|
| | Med | High | |

## 11. Research — SUGGESTED

| | |
|---|---|
| **Key research questions** | what must we answer to de-risk design decisions? |
| **Prior findings / insights** | link existing research; summarize what's known |
| **Planned methods** | interviews, usability tests, surveys, analytics — and when |
| **Validation plan** | how and when we'll test designs before or after release |

## 12. Timeline & milestones — SUGGESTED

| Milestone | Owner | Target date | Status |
|---|---|---|---|
| Discovery / research complete | | | |
| Wireframes / concept review | | | |
| Hi-fi & design review | | | |
| Handoff to engineering | | | |

## 13. Open questions — LEAN CORE

| Question | Owner | Raised | Answer / status |
|---|---|---|---|
| | | | **Bold the answer when resolved** |

House convention: once answered, the answer goes **bold, inline, in place**. Do not delete the
question — the trail is worth more than a clean list.

## 14. Decisions log — SUGGESTED

| Date | Decision | Rationale | Decided by |
|---|---|---|---|

## 15. Approvals & sign-off — SUGGESTED

| Approver & role | Date | Status / conditions |
|---|---|---|
| PM | | Approved / changes requested |
| Eng lead | | |
| Design lead | | |

## 16. Revision history — SUGGESTED

| Date | Author | Change |
|---|---|---|
