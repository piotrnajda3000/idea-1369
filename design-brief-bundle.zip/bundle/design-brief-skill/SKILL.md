---
name: design-brief
description: Generate a structured UX project brief from whatever input you have — a Jira ticket, a PRD link, a Figma file, or a paragraph of rough description. Fills Min's UX Project Brief format, marks every unknown as an explicit gap, and interrogates the weak sections instead of inventing answers. Use at the start of a new feature or project when you want a forcing function to think it through before designing. Triggers on "design brief", "UX brief", "project brief", "write a brief for", "kick off", "/design-brief".
---

# Design brief

Turn a prompt, a ticket, or a PRD into a UX Project Brief in the house format.

The brief's value is not the document — it is the questions it forces. A brief full of
confident-sounding filler is worse than no brief. **Never invent a fact.** Every unknown
becomes a visible `[TBD]` and a row in Open questions with an owner.

## Files

- `references/template.md` — the full 16-section format. LEAN CORE vs SUGGESTED marked.
- `references/definition-questions.md` — the question bank for any form, config or calculator surface. Read it at Step 3.
- `references/house-style.md` — table shapes, priority/status vocab, and the anti-patterns to refuse.
- `scripts/brief_to_html.py` — converts the finished brief to Docs-pasteable HTML.

## Step 1 — Read the input

The user may give you any of these, in any combination. Take what you get.

| Input | What to do |
|---|---|
| Jira key (`IDEA-1727`, `AV-94227`) | Fetch via the Atlassian tools. If the instance isn't reachable, say so once and ask the user to paste the ticket text — do not guess at contents. |
| Google Doc / PRD link | Read it with the Drive tools. Extract problem, users, scope, requirements. |
| Confluence page | Read it via the Atlassian tools. |
| Figma link | `get_metadata` / `get_screenshot` for existing flows and screen names. |
| Repo path or component name | Search the codebase for current behaviour, states, and enums — these become the States & edge cases table. |
| A paragraph of description | That is enough to start. Go straight to Step 2, then lean hard on Step 4. |
| Nothing but a project name | Ask for one input before drafting. Do not draft from a title alone. |

Follow the links you find. A PRD linked from the ticket, an architecture doc linked from the
PRD — read one level deep, and stop. Note in Summary → Links every doc you actually read.

## Step 2 — Draft the LEAN CORE

Fill these nine sections. They are what the real briefs actually carry:

1. **Summary** — Links, Team & stakeholders, Plan & deliverables
2. **Background / context** — 3–5 sentences: current state, the pain, what triggered this now
3. **Problem statement** — one or two sentences: `[User] needs a way to [goal] because [pain], but today [obstacle].`
4. **Objective** — the outcome, not the feature list. One sentence. (Good: *"Self-service recovery without a ticket or using a CLI."*)
5. **Success metrics & key results** — metric / leading-lagging / baseline / target
6. **User stories & user tasks** — the core of the brief. Table, prioritised, with status
7. **States & edge cases** — two tables. Empty, loading, error, partial-permission, first-run, too-much-data
8. **Platform impact & prerequisites** — billing, security, RBAC compatibility, performance, prerequisites and dependencies
9. **Open questions** — every `[TBD]` above lands here with an owner

**Platform impact: check all six, publish what's live.** Run every dimension — billing,
security, RBAC, performance, prerequisites, dependencies — against every project, however
unrelated they look. Most will come back clean, and that is fine: they collapse into a single
"checked, no impact" line rather than a table of noes.

But each clean dimension carries the one clause that proves you looked — *"no new metered
resource, no change to tier gating"* — because a bare "no" is indistinguishable from an
unchecked box, and it is the clause a reviewer can argue with. Never write "no impact" for a
dimension the source simply doesn't mention; that is `[TBD]` plus an open question.

Two of the six bite hardest:

- **RBAC compatibility.** Specs grant permission by capability ("anyone who can deploy a
  cluster"); the platform grants by named role. Map one to the other and say whether the
  permission exists today. Check the real role names in `internal/rbac` rather than guessing,
  and note what a user without the permission sees.
- **Prerequisites vs dependencies.** A prerequisite must ship first; a dependency ships
  alongside. Conflating them hides the critical path.

**Promotion rule.** If the project has a form, wizard, calculator, or configuration surface —
anything where the user fills in fields and gets a result — then **Objects, fields & provenance**
and **IA & key flows** are LEAN CORE too, not SUGGESTED. Those two sections are where the
Step 3 answers live, and a config surface briefed without them will be designed on guesswork.

Rules while drafting:

- Anything the input does not tell you is `[TBD]` — never a plausible placeholder. No invented
  names, dates, metrics, or stakeholder assignments.
- Derive user stories from the source material; don't pad the table to look complete. Five real
  stories beat twelve generic ones.
- If the source is a PRD, translate it — do not transcribe it. The PRD says what gets built; the
  brief says who needs it and why. Where the PRD hedges ("Available or Linked"), name the hedge
  as an open question rather than picking one silently.
- Team & stakeholders: include every role the source actually names. Specs routinely list SRE,
  Support, Performance, Documentation and Field Engineering as approvers — carry them across
  rather than forcing the roles into the template's shorter default list.
- Status: for a new brief `Not Started` is the honest default, but if the source says design is
  already underway, say so under the table and raise it as an open question. Do not silently
  imply nothing has happened.
- Read `references/house-style.md` before writing any table.

## Step 3 — Run the definition checks

**Whenever the project involves a form, config, wizard or calculator**, read
`references/definition-questions.md` and run all nine classes against the draft:

object identity · field provenance · value sourcing · completeness · dependency and order ·
duplication · terminal state · placement · action legibility

These are the questions that are cheap now and expensive in review. Each one the source cannot
answer becomes a row in Open questions, routed to the section named in that file's last table.

Two that earn special attention because specs almost always skip them:

- **Field provenance.** For every field, is the value user input, a suggested default, computed,
  system-generated, or locked? If the brief doesn't say, the design will mix them and the user
  will not know which numbers are theirs to change.
- **Terminal state.** What does the primary action produce, where does the output appear, and
  what does the user do next? A spec that leaves this "TBD" has left its largest surface
  undefined — name it as such, at the priority the spec itself assigns.

Keep these separate from critique. Layout, grouping, spacing, component styling and
scannability are review-time concerns — route those to `/review-design`, not into the brief.

## Step 4 — Interrogate the weak sections

**Ordering.** When the input is a substantial document — a PRD, a spec, a Confluence page —
draft first, then interrogate: the draft is what surfaces the real questions, and asking before
reading produces generic ones. When the input is a paragraph of description or less, interrogate
before drafting, because there is nothing yet to interrogate against.

Pick the **three weakest sections** and ask targeted questions about those — not a generic
questionnaire. Batch them into one round.

Targeted beats generic:

| Weak draft | Don't ask | Ask |
|---|---|---|
| Audience is "Capella users" | "Who is the audience?" | "Which one person is most likely to hit this first — the admin who set the cluster up, or the developer who inherited it?" |
| Objective has no measure | "What are the success metrics?" | "Six months after launch, what number tells you this worked?" |
| Scope is unbounded | "What's in scope?" | "What is the smallest version you would still ship? What are you deliberately *not* doing in v1?" |
| No states listed | "Any edge cases?" | "What does this screen show before any data exists, and what does it show when the collector is offline?" |
| A form with undeclared fields | "Is the form clear?" | "Which of these values does the user supply, and which does the tool compute and hand back?" |
| A primary action with no stated result | "What does the button do?" | "After they hit Calculate — what appears, where, and what are they meant to do with it?" |
| No sign-off owner | "Who approves?" | "Who has to say yes before this goes to engineering — and what would make them say no?" |

If the user says "just draft it, I'll fill the gaps" — do that. Write the file with the `[TBD]`s
intact and the Open questions table populated. The gaps are the deliverable in that case.

## Step 5 — Write the files

Choose the location:

- If the working directory is inside a **git repository**, write to the session scratchpad
  instead — a brief is not a repo artifact and shouldn't dirty the tree. Say where you put it.
- Otherwise write to the working directory, or to a path the user names.

Two files:

- `<project-slug>-brief.md` — the brief
- `<project-slug>-brief.html` — the same brief, Docs-pasteable

```bash
python3 ~/.claude/skills/design-brief/scripts/brief_to_html.py <project-slug>-brief.md
```

Then tell the user, in one line: open the `.html` in a browser, select all, copy, and paste into
the Google Doc — tables survive the paste; markdown tables pasted directly into Docs do not.

Send both files with SendUserFile.

## Step 6 — Offer the SUGGESTED sections

Do not bulk-append the remaining SUGGESTED sections. Instead, name the two or three that would
earn their place *for this project*, with a reason, and ask. Judgement cues:

| Add | When |
|---|---|
| Target users & context of use | More than one user type, or the users work in different environments |
| Scope & phasing | Anything multi-release, or where scope creep is the live risk |
| Objects, fields & provenance | Any form, config, wizard or calculator — promoted to LEAN CORE by Step 2 |
| IA & key flows | Greenfield, the navigation is changing, or a new surface needs entry points from existing ones |
| Assumptions, constraints & dependencies | Unvalidated beliefs and fixed constraints — prerequisites and dependencies now live in the LEAN CORE platform-impact section |
| Risks & mitigations | Timeline pressure, or a known-shaky dependency |
| Research | Real unknowns about user behaviour, not just implementation |
| Timeline & milestones | Committed release date exists |
| Decisions log | Long-running project where "why is it like this" will get asked |
| Approvals & sign-off / Revision history | The brief will be reviewed by people who weren't in the room |

## Updating an existing brief

If the user points at a brief that already exists, do not regenerate it. Read it, then:

- Add only what the new input actually changes.
- Move resolved open questions to **bold inline answers** in place — that is the house convention,
  and the answer trail is worth more than a clean list.
- Never delete an open question just because it went stale. Mark it.
- Append to Revision history if that section exists.
