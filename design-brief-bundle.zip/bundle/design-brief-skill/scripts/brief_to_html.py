#!/usr/bin/env python3
"""Convert a brief written in markdown to HTML you can paste into Google Docs.

Docs discards most CSS but honours table structure, bold, italics, links and lists from an
HTML clipboard payload — so tables survive a browser select-all/copy/paste, which they do not
when you paste markdown directly.

Usage:  brief_to_html.py <brief.md> [-o out.html]
Stdlib only.
"""

import argparse
import html
import pathlib
import re
import sys

INLINE = (
    (re.compile(r"`([^`]+)`"), lambda m: f"<code>{m.group(1)}</code>"),
    (re.compile(r"\*\*([^*]+)\*\*"), lambda m: f"<strong>{m.group(1)}</strong>"),
    (re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)"), lambda m: f"<em>{m.group(1)}</em>"),
    (re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)"), lambda m: f'<a href="{m.group(2)}">{m.group(1)}</a>'),
)

TABLE_ROW = re.compile(r"^\s*\|(.+)\|\s*$")
DIVIDER = re.compile(r"^\s*\|[\s:|-]*-[\s:|-]*\|\s*$")  # must contain a dash
HEADING = re.compile(r"^(#{1,6})\s+(.*)$")
BULLET = re.compile(r"^(\s*)[-*+]\s+(.*)$")
ORDERED = re.compile(r"^(\s*)\d+[.)]\s+(.*)$")

STYLE = """
body { font-family: Arial, Helvetica, sans-serif; font-size: 11pt; line-height: 1.5;
       max-width: 8.5in; margin: 2em auto; padding: 0 1em; color: #111; }
h1 { font-size: 20pt; } h2 { font-size: 15pt; margin-top: 1.6em; } h3 { font-size: 12pt; }
table { border-collapse: collapse; width: 100%; margin: 1em 0; }
th, td { border: 1px solid #999; padding: 6px 9px; text-align: left; vertical-align: top; }
th { background: #f1f3f4; font-weight: bold; }
code { font-family: 'Courier New', monospace; background: #f1f3f4; padding: 0 3px; }
"""


def inline(text: str) -> str:
    out = html.escape(text, quote=False)
    for pattern, repl in INLINE:
        out = pattern.sub(repl, out)
    return out


def split_row(line: str) -> list[str]:
    body = TABLE_ROW.match(line).group(1)
    # Split on pipes that are not escaped.
    cells = re.split(r"(?<!\\)\|", body)
    return [c.strip().replace(r"\|", "|") for c in cells]


def render_table(lines: list[str]) -> list[str]:
    rows = [split_row(l) for l in lines if not DIVIDER.match(l)]
    if not rows:
        return []
    has_header = len(lines) > 1 and DIVIDER.match(lines[1]) is not None
    out = ["<table>"]
    for i, row in enumerate(rows):
        tag = "th" if (has_header and i == 0) else "td"
        cells = "".join(f"<{tag}>{inline(c)}</{tag}>" for c in row)
        out.append(f"  <tr>{cells}</tr>")
    out.append("</table>")
    return out


def convert(md: str) -> str:
    lines = md.splitlines()
    out: list[str] = []
    list_stack: list[str] = []
    i = 0

    def close_lists(depth: int = 0) -> None:
        while len(list_stack) > depth:
            out.append(f"</{list_stack.pop()}>")

    while i < len(lines):
        line = lines[i]

        if TABLE_ROW.match(line) and not DIVIDER.match(line):
            block = []
            while i < len(lines) and TABLE_ROW.match(lines[i]):
                block.append(lines[i])
                i += 1
            close_lists()
            out.extend(render_table(block))
            continue

        if not line.strip():
            close_lists()
            i += 1
            continue

        if line.strip() in ("---", "***", "___"):
            close_lists()
            out.append("<hr>")
            i += 1
            continue

        m = HEADING.match(line)
        if m:
            close_lists()
            level = len(m.group(1))
            out.append(f"<h{level}>{inline(m.group(2).strip())}</h{level}>")
            i += 1
            continue

        m = BULLET.match(line) or ORDERED.match(line)
        if m:
            tag = "ul" if BULLET.match(line) else "ol"
            depth = len(m.group(1).expandtabs(4)) // 2 + 1
            close_lists(depth)
            while len(list_stack) < depth:
                out.append(f"<{tag}>")
                list_stack.append(tag)
            out.append(f"<li>{inline(m.group(2))}</li>")
            i += 1
            continue

        close_lists()
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip() and not (
            HEADING.match(lines[i]) or TABLE_ROW.match(lines[i])
            or BULLET.match(lines[i]) or ORDERED.match(lines[i])
        ):
            para.append(lines[i].strip())
            i += 1
        out.append(f"<p>{inline(' '.join(para))}</p>")

    close_lists()
    return "\n".join(out)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("source", help="brief written in markdown")
    ap.add_argument("-o", "--out", help="output path (default: alongside the source, .html)")
    args = ap.parse_args()

    src = pathlib.Path(args.source)
    if not src.is_file():
        print(f"no such file: {src}", file=sys.stderr)
        return 1

    md = src.read_text(encoding="utf-8")
    title = next((l.lstrip("# ").strip() for l in md.splitlines() if l.startswith("# ")), src.stem)
    dest = pathlib.Path(args.out) if args.out else src.with_suffix(".html")
    dest.write_text(
        "<!doctype html>\n<html><head><meta charset=\"utf-8\">"
        f"<title>{html.escape(title)}</title><style>{STYLE}</style></head><body>\n"
        f"{convert(md)}\n</body></html>\n",
        encoding="utf-8",
    )
    print(dest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
