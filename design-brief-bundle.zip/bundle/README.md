# design-brief — skill bundle

## Contents

    design-brief-skill/          the skill itself
      SKILL.md                   the process: read input, draft, run checks, interrogate, write
      references/
        template.md              the 16-section brief format (LEAN CORE vs SUGGESTED marked)
        definition-questions.md  9-class question bank for form/config/calculator surfaces
        house-style.md           table shapes, priority/status vocab, anti-patterns
      scripts/
        brief_to_html.py         markdown brief -> Docs-pasteable HTML

    example-output/              generated from the Sizing/Workload/Scaling Insights PRD
      sizing-workload-scaling-insights-brief.md
      sizing-workload-scaling-insights-brief.html

## Install

Copy the skill into your Claude Code skills directory:

    cp -R design-brief-skill ~/.claude/skills/design-brief

Then invoke with `/design-brief` plus any input — a Jira key, a PRD link, a Figma URL, or a
paragraph of description.

## Docs handoff

Markdown tables pasted into Google Docs arrive as plain text. Open the `.html` in a browser,
select all, copy, paste into the Doc — tables, bold and links survive.
